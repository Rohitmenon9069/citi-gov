"""
CiTiGov — Flask Backend API
India Digital Trust Analytics Platform
"""
from flask import Flask, jsonify, request, abort
from flask_cors import CORS
import sqlite3, os, random, string, datetime, json, time

app = Flask(__name__, static_folder='../', static_url_path='')
CORS(app)  # Allow all origins for dev

# Serve index.html at root
@app.route('/')
def index():
    return app.send_static_file('index.html')

# Serve other HTML files directly (login.html, signup.html)
@app.route('/<path:path>')
def serve_html(path):
    if path.endswith('.html'):
        return app.send_static_file(path)
    return abort(404)

DB_PATH = os.path.join(os.path.dirname(__file__), 'citigov.db')

# ── DB Init ──────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS feedback (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        rating      INTEGER NOT NULL,
        message     TEXT,
        service     TEXT DEFAULT 'General',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS complaints (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id   TEXT UNIQUE NOT NULL,
        name        TEXT,
        service     TEXT NOT NULL,
        category    TEXT NOT NULL,
        description TEXT NOT NULL,
        status      TEXT DEFAULT 'Received',
        priority    TEXT DEFAULT 'Medium',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS quiz_results (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        score       INTEGER NOT NULL,
        answers     TEXT,
        trust_level TEXT,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS page_visits (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        section     TEXT,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS service_issues (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        service     TEXT NOT NULL,
        issue       TEXT NOT NULL,
        reported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        resolved    INTEGER DEFAULT 0
    );
    """)
    conn.commit()
    conn.close()

init_db()

def gen_ticket():
    prefix = "CG"
    date   = datetime.datetime.now().strftime("%d%m")
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"{prefix}{date}{suffix}"

# ══════════════════════════════════════════════════════════════
# TRUST METRICS  GET /api/metrics
# ══════════════════════════════════════════════════════════════
@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    db   = get_db()
    c    = db.cursor()
    total_feedback  = c.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
    avg_rating      = c.execute("SELECT AVG(rating) FROM feedback").fetchone()[0] or 0
    total_complaints= c.execute("SELECT COUNT(*) FROM complaints").fetchone()[0]
    resolved        = c.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0]
    db.close()

    return jsonify({
        "trust_index": 54,
        "trend": "+9pp",
        "baseline_year": 2024,
        "baseline_value": 45,
        "total_feedback": total_feedback,
        "avg_rating": round(avg_rating, 2),
        "total_complaints": total_complaints,
        "resolved_complaints": resolved,
        "resolution_rate": round((resolved / total_complaints * 100) if total_complaints else 0, 1),
        "states": {
            "Telangana": 71, "Karnataka": 67, "Maharashtra": 62,
            "Gujarat": 60, "Tamil Nadu": 58, "Delhi": 56,
            "National Avg": 54, "Rajasthan": 48, "Uttar Pradesh": 41, "Bihar": 33
        },
        "services": {
            "UPI": 72, "DigiLocker": 68, "IRCTC": 65,
            "UMANG": 54, "eCourts": 48, "News Media": 18
        },
        "pillars": {
            "security":     {"score": 63, "label": "Security & Data Protection"},
            "transparency": {"score": 62, "label": "Transparency & Openness"},
            "quality":      {"score": 75, "label": "Service Quality & Reliability"},
            "ux":           {"score": 67, "label": "User-Friendly Design"}
        },
        "timestamp": datetime.datetime.now().isoformat()
    })

# ══════════════════════════════════════════════════════════════
# SERVICE STATUS  GET /api/status
# ══════════════════════════════════════════════════════════════
SERVICES_CONFIG = [
    {"id": "aadhaar",    "name": "Aadhaar / UIDAI",  "icon": "🪪", "owner": "UIDAI",   "url": "uidai.gov.in"},
    {"id": "digilocker", "name": "DigiLocker",        "icon": "📁", "owner": "MeitY",   "url": "digilocker.gov.in"},
    {"id": "umang",      "name": "UMANG App",         "icon": "📱", "owner": "NeGD",    "url": "web.umang.gov.in"},
    {"id": "upi",        "name": "UPI / NPCI",        "icon": "💳", "owner": "NPCI",    "url": "npci.org.in"},
    {"id": "irctc",      "name": "IRCTC Rail Connect","icon": "🚆", "owner": "IRCTC",   "url": "irctc.co.in"},
    {"id": "incometax",  "name": "Income Tax Portal", "icon": "💰", "owner": "CBDT",    "url": "incometax.gov.in"},
    {"id": "cowin",      "name": "CoWIN / Health Stack","icon":"💉", "owner": "MoHFW",  "url": "cowin.gov.in"},
    {"id": "parivahan",  "name": "Parivahan Sewa",    "icon": "🚗", "owner": "MoRTH",   "url": "parivahan.gov.in"},
    {"id": "myscheme",   "name": "MyScheme Portal",   "icon": "🏛️", "owner": "MeitY",  "url": "myscheme.gov.in"},
    {"id": "passport",   "name": "Passport Seva",     "icon": "🛂", "owner": "MEA",     "url": "passportindia.gov.in"},
]

# Simulate realistic uptime with some variation
_status_cache = {"data": None, "ts": 0}

def get_service_statuses():
    now = time.time()
    if now - _status_cache["ts"] < 30:   # cache 30s
        return _status_cache["data"]

    db   = get_db()
    c    = db.cursor()
    statuses = []
    for svc in SERVICES_CONFIG:
        # Pull active issues from DB
        issues = c.execute(
            "SELECT issue FROM service_issues WHERE service=? AND resolved=0 ORDER BY reported_at DESC LIMIT 1",
            (svc["id"],)
        ).fetchone()

        # Deterministic uptime seeded by service id for demo stability
        seed = sum(ord(ch) for ch in svc["id"]) + int(now // 300)
        rng  = random.Random(seed)
        uptime = round(rng.uniform(97.5, 99.98), 2)
        response_ms = rng.randint(80, 450)

        if issues:
            status = "degraded"
            detail = issues["issue"]
        elif uptime > 99.5:
            status = "operational"
            detail = "All systems normal"
        elif uptime > 98:
            status = "partial"
            detail = "Minor delays reported"
        else:
            status = "degraded"
            detail = "Performance degraded"

        statuses.append({
            **svc,
            "status": status,
            "uptime": uptime,
            "response_ms": response_ms,
            "detail": detail,
            "last_checked": datetime.datetime.now().strftime("%H:%M:%S")
        })
    db.close()

    _status_cache["data"] = statuses
    _status_cache["ts"]   = now
    return statuses

@app.route('/api/status', methods=['GET'])
def service_status():
    statuses = get_service_statuses()
    operational = sum(1 for s in statuses if s["status"] == "operational")
    return jsonify({
        "services": statuses,
        "summary": {
            "total": len(statuses),
            "operational": operational,
            "degraded": sum(1 for s in statuses if s["status"] == "degraded"),
            "partial": sum(1 for s in statuses if s["status"] == "partial"),
            "overall": "operational" if operational >= len(statuses) - 1 else "partial"
        },
        "timestamp": datetime.datetime.now().isoformat()
    })

# ══════════════════════════════════════════════════════════════
# FEEDBACK  POST /api/feedback  GET /api/feedback/summary
# ══════════════════════════════════════════════════════════════
@app.route('/api/feedback', methods=['POST'])
def post_feedback():
    data = request.get_json(silent=True) or {}
    rating  = data.get('rating')
    message = data.get('message', '').strip()
    service = data.get('service', 'General')

    if not rating or not isinstance(rating, int) or rating < 1 or rating > 5:
        return jsonify({"error": "Rating must be 1–5"}), 400

    db = get_db()
    db.execute("INSERT INTO feedback (rating, message, service) VALUES (?,?,?)",
               (rating, message, service))
    db.commit()
    db.close()
    return jsonify({"success": True, "message": "Feedback recorded. धन्यवाद!"}), 201

@app.route('/api/feedback/summary', methods=['GET'])
def feedback_summary():
    db  = get_db()
    c   = db.cursor()
    rows = c.execute("""
        SELECT rating, COUNT(*) cnt FROM feedback GROUP BY rating ORDER BY rating
    """).fetchall()
    recent = c.execute("""
        SELECT rating, message, service, created_at FROM feedback
        ORDER BY created_at DESC LIMIT 10
    """).fetchall()
    total   = c.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
    avg     = c.execute("SELECT AVG(rating) FROM feedback").fetchone()[0] or 0
    db.close()
    return jsonify({
        "total": total,
        "average": round(avg, 2),
        "distribution": {str(r["rating"]): r["cnt"] for r in rows},
        "recent": [dict(r) for r in recent]
    })

# ══════════════════════════════════════════════════════════════
# COMPLAINTS  POST /api/complaints  GET /api/complaints/<ticket_id>
# ══════════════════════════════════════════════════════════════
VALID_SERVICES   = ["Aadhaar/UIDAI","DigiLocker","UMANG","UPI/NPCI","IRCTC","Income Tax Portal","Passport Seva","Parivahan","Other"]
VALID_CATEGORIES = ["Technical Error","Login/OTP Failure","Data Mismatch","Slow Response","Feature Request","Accessibility","Fraud/Security","Other"]

@app.route('/api/complaints', methods=['POST'])
def submit_complaint():
    data = request.get_json(silent=True) or {}
    service     = data.get('service', '').strip()
    category    = data.get('category', '').strip()
    description = data.get('description', '').strip()
    name        = data.get('name', 'Anonymous').strip()

    if not service or not category or len(description) < 20:
        return jsonify({"error": "Please fill all fields. Description must be at least 20 characters."}), 400

    ticket_id = gen_ticket()
    priority  = "High" if category in ["Fraud/Security","Technical Error"] else "Medium"

    db = get_db()
    db.execute("""
        INSERT INTO complaints (ticket_id, name, service, category, description, priority)
        VALUES (?,?,?,?,?,?)
    """, (ticket_id, name, service, category, description, priority))
    db.commit()
    db.close()

    return jsonify({
        "success": True,
        "ticket_id": ticket_id,
        "message": f"Complaint registered! Track with ID: {ticket_id}",
        "priority": priority,
        "expected_resolution": "3–5 business days"
    }), 201

@app.route('/api/complaints/<ticket_id>', methods=['GET'])
def track_complaint(ticket_id):
    db  = get_db()
    row = db.execute("SELECT * FROM complaints WHERE ticket_id=?", (ticket_id.upper(),)).fetchone()
    db.close()
    if not row:
        return jsonify({"error": "Ticket not found. Please check the ID."}), 404
    d = dict(row)

    # Build a simple timeline
    created = d["created_at"]
    timeline = [
        {"step": "Complaint Received",   "status": "done",    "time": created},
        {"step": "Under Review",         "status": "done" if d["status"] != "Received" else "active", "time": ""},
        {"step": "Escalated to Agency",  "status": "done" if d["status"] == "Resolved" else "pending", "time": ""},
        {"step": "Resolved",             "status": "done" if d["status"] == "Resolved" else "pending", "time": d.get("updated_at","") if d["status"] == "Resolved" else ""},
    ]
    d["timeline"] = timeline
    return jsonify(d)

@app.route('/api/complaints', methods=['GET'])
def list_complaints():
    db   = get_db()
    rows = db.execute("""
        SELECT ticket_id, service, category, status, priority, created_at
        FROM complaints ORDER BY created_at DESC LIMIT 50
    """).fetchall()
    db.close()
    return jsonify({"complaints": [dict(r) for r in rows]})

# Admin: update complaint status
@app.route('/api/complaints/<ticket_id>/status', methods=['PATCH'])
def update_status(ticket_id):
    data   = request.get_json(silent=True) or {}
    status = data.get('status')
    if status not in ["Received","Under Review","Escalated","Resolved"]:
        return jsonify({"error": "Invalid status"}), 400
    db = get_db()
    affected = db.execute(
        "UPDATE complaints SET status=?, updated_at=CURRENT_TIMESTAMP WHERE ticket_id=?",
        (status, ticket_id.upper())
    ).rowcount
    db.commit()
    db.close()
    if not affected:
        return jsonify({"error": "Ticket not found"}), 404
    return jsonify({"success": True, "ticket_id": ticket_id.upper(), "new_status": status})

# ══════════════════════════════════════════════════════════════
# QUIZ RESULTS  POST /api/quiz
# ══════════════════════════════════════════════════════════════
@app.route('/api/quiz', methods=['POST'])
def save_quiz():
    data    = request.get_json(silent=True) or {}
    score   = data.get('score', 0)
    answers = json.dumps(data.get('answers', []))
    levels  = {range(0,4): "Low Trust", range(4,7): "Moderate Trust",
               range(7,10): "High Trust", range(10,11): "Champion"}
    trust_level = next((v for k,v in levels.items() if score in k), "Moderate Trust")
    db = get_db()
    db.execute("INSERT INTO quiz_results (score, answers, trust_level) VALUES (?,?,?)",
               (score, answers, trust_level))
    db.commit()
    total = db.execute("SELECT COUNT(*) FROM quiz_results").fetchone()[0]
    avg   = db.execute("SELECT AVG(score) FROM quiz_results").fetchone()[0] or 0
    db.close()
    return jsonify({
        "success": True,
        "score": score,
        "trust_level": trust_level,
        "percentile": min(int((score / 10) * 100), 99),
        "avg_score": round(avg, 1),
        "total_participants": total
    }), 201

# ══════════════════════════════════════════════════════════════
# NEWS FEED  GET /api/news
# ══════════════════════════════════════════════════════════════
NEWS = [
    {"id":1,"title":"DPDP Act 2023 enforcement begins — penalties for data breaches up to ₹250 Cr","category":"Policy","date":"2025-03-20","urgency":"high","icon":"⚖️","source":"MeitY"},
    {"id":2,"title":"DigiLocker crosses 310 million users; 6.5 billion documents issued","category":"Milestone","date":"2025-03-18","urgency":"low","icon":"📁","source":"MeitY"},
    {"id":3,"title":"UMANG app UX redesign pilot launches in 5 states","category":"Update","date":"2025-03-15","urgency":"medium","icon":"📱","source":"NeGD"},
    {"id":4,"title":"UPI records 500 Crore transactions in February 2025","category":"Milestone","date":"2025-03-10","urgency":"low","icon":"💳","source":"NPCI"},
    {"id":5,"title":"India ranks 6th globally on e-Government Development Index 2025","category":"Recognition","date":"2025-03-08","urgency":"low","icon":"🏆","source":"UN"},
    {"id":6,"title":"New Grievance Portal integrates 24 ministries for faster resolution","category":"Launch","date":"2025-03-05","urgency":"medium","icon":"🏛️","source":"DARPG"},
    {"id":7,"title":"BharatNet Phase III: 2.5 lakh gram panchayats to get fiber connectivity","category":"Infrastructure","date":"2025-03-01","urgency":"medium","icon":"🌐","source":"DoT"},
    {"id":8,"title":"Aadhaar-based biometric authentication hits 99.98% success rate","category":"Update","date":"2025-02-25","urgency":"low","icon":"🪪","source":"UIDAI"},
    {"id":9,"title":"CERT-In mandates 6-hour breach reporting for all government portals","category":"Security","date":"2025-02-20","urgency":"high","icon":"🛡️","source":"CERT-In"},
    {"id":10,"title":"AI governance framework consultation paper released by MeitY","category":"Policy","date":"2025-02-15","urgency":"medium","icon":"🤖","source":"MeitY"},
]

@app.route('/api/news', methods=['GET'])
def get_news():
    category = request.args.get('category')
    filtered = [n for n in NEWS if not category or n["category"] == category]
    return jsonify({
        "news": filtered,
        "categories": list({n["category"] for n in NEWS}),
        "total": len(filtered)
    })

# ══════════════════════════════════════════════════════════════
# REPORT SERVICE ISSUE  POST /api/report-issue
# ══════════════════════════════════════════════════════════════
@app.route('/api/report-issue', methods=['POST'])
def report_issue():
    data    = request.get_json(silent=True) or {}
    service = data.get('service', '').strip()
    issue   = data.get('issue', '').strip()
    if not service or not issue:
        return jsonify({"error": "service and issue are required"}), 400
    db = get_db()
    db.execute("INSERT INTO service_issues (service, issue) VALUES (?,?)", (service, issue))
    db.commit()
    db.close()
    _status_cache["ts"] = 0  # Bust status cache
    return jsonify({"success": True, "message": "Issue reported. Thank you for helping improve Digital India!"}), 201

# ══════════════════════════════════════════════════════════════
# ANALYTICS  GET /api/analytics
# ══════════════════════════════════════════════════════════════
@app.route('/api/analytics', methods=['GET'])
def analytics():
    db = get_db()
    c  = db.cursor()
    complaints_by_service  = c.execute("""
        SELECT service, COUNT(*) cnt FROM complaints GROUP BY service ORDER BY cnt DESC
    """).fetchall()
    complaints_by_status   = c.execute("""
        SELECT status, COUNT(*) cnt FROM complaints GROUP BY status
    """).fetchall()
    feedback_trend = c.execute("""
        SELECT DATE(created_at) day, AVG(rating) avg_rating, COUNT(*) cnt
        FROM feedback GROUP BY DATE(created_at) ORDER BY day DESC LIMIT 14
    """).fetchall()
    quiz_dist = c.execute("""
        SELECT trust_level, COUNT(*) cnt FROM quiz_results GROUP BY trust_level
    """).fetchall()
    db.close()
    return jsonify({
        "complaints_by_service": [dict(r) for r in complaints_by_service],
        "complaints_by_status":  [dict(r) for r in complaints_by_status],
        "feedback_trend":        [dict(r) for r in feedback_trend],
        "quiz_distribution":     [dict(r) for r in quiz_dist],
    })

# ══════════════════════════════════════════════════════════════
# SCHEMES  GET /api/schemes?age=&income=&state=
# ══════════════════════════════════════════════════════════════
SCHEMES = [
    {"name":"PM-KISAN","desc":"₹6,000/year for small farmers","eligibility":{"occupation":"Farmer"},"icon":"🌾","ministry":"Agriculture"},
    {"name":"Ayushman Bharat","desc":"₹5 lakh health insurance","eligibility":{"income_max":300000},"icon":"🏥","ministry":"Health"},
    {"name":"PM Awas Yojana","desc":"Housing assistance for EWS/LIG","eligibility":{"income_max":600000},"icon":"🏠","ministry":"Housing"},
    {"name":"Sukanya Samriddhi","desc":"8.2% interest savings for girl child","eligibility":{"age_max":10,"gender":"Female"},"icon":"👧","ministry":"Finance"},
    {"name":"PM Mudra Yojana","desc":"Loan up to ₹10 lakh for small business","eligibility":{"occupation":"Business"},"icon":"💼","ministry":"Finance"},
    {"name":"National Scholarship Portal","desc":"Merit-based scholarships for students","eligibility":{"age_max":30,"occupation":"Student"},"icon":"📚","ministry":"Education"},
    {"name":"Ujjwala Yojana","desc":"Free LPG connection for BPL families","eligibility":{"income_max":100000},"icon":"🔥","ministry":"Petroleum"},
    {"name":"Atal Pension Yojana","desc":"Guaranteed pension of ₹1000–5000/month","eligibility":{"age_min":18,"age_max":40},"icon":"🧓","ministry":"Finance"},
    {"name":"Stand-Up India","desc":"Loans ₹10L–₹1Cr for SC/ST entrepreneurs","eligibility":{"occupation":"Business"},"icon":"🚀","ministry":"Finance"},
    {"name":"PM Vishwakarma","desc":"Skill & credit support for artisans","eligibility":{"occupation":"Artisan"},"icon":"🔨","ministry":"MSME"},
]

@app.route('/api/schemes', methods=['GET'])
def get_schemes():
    age    = request.args.get('age', type=int)
    income = request.args.get('income', type=int)
    occ    = request.args.get('occupation', '').strip().title()
    result = []
    for s in SCHEMES:
        e = s["eligibility"]
        if age:
            if "age_min" in e and age < e["age_min"]: continue
            if "age_max" in e and age > e["age_max"]: continue
        if income and "income_max" in e and income > e["income_max"]: continue
        if occ and "occupation" in e and e["occupation"].lower() != occ.lower(): continue
        result.append({k:v for k,v in s.items() if k != "eligibility"})
    return jsonify({"schemes": result, "total": len(result),
                    "query": {"age": age, "income": income, "occupation": occ}})

# ══════════════════════════════════════════════════════════════
# HEALTH CHECK
# ══════════════════════════════════════════════════════════════
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "ok", "service": "CiTiGov API",
                    "version": "2.0.0", "timestamp": datetime.datetime.now().isoformat()})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"CiTiGov Backend Starting on http://0.0.0.0:{port}")
    app.run(debug=False, port=port, host='0.0.0.0')
